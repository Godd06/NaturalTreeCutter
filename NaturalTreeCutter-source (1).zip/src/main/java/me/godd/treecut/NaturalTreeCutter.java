package me.godd.treecut;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

/**
 * NaturalTreeCutter - plugin source (uncompiled).
 *
 * This plugin stores coordinates of wooden-type blocks placed by players and ignores them when performing automatic
 * tree cutting. It also provides a simple upward-only "tree cut" that breaks contiguous log blocks above the broken one.
 *
 * Build instructions are included in the README.
 */
public class NaturalTreeCutter extends JavaPlugin implements Listener {

    private final Set<String> playerPlacedBlocks = new HashSet<>();
    private final Set<Material> woodenMaterials = EnumSet.noneOf(Material.class);
    private File dataFile;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("NaturalTreeCutter enabled!");

        // Build the set of materials that are considered "wooden" or wood-derived.
        for (Material mat : Material.values()) {
            String name = mat.name();
            if (name.contains("WOOD") ||
                name.contains("LOG") ||
                name.contains("PLANKS") ||
                name.contains("FENCE") ||
                name.contains("GATE") ||
                name.contains("DOOR") ||
                name.contains("TRAPDOOR") ||
                name.contains("BUTTON") ||
                name.contains("PRESSURE_PLATE") ||
                name.contains("SIGN") ||
                name.contains("STAIRS") ||
                name.contains("SLAB") ||
                name.contains("CHEST") ||
                name.contains("BOOKSHELF") ||
                name.contains("BARREL") ||
                name.contains("LECTERN") ||
                name.contains("BEEHIVE") ||
                name.contains("BEE_NEST") ||
                name.contains("JUKEBOX")) {
                woodenMaterials.add(mat);
            }
        }

        // Data file to persist placed blocks between restarts
        dataFile = new File(getDataFolder(), "placed_blocks.txt");
        if (dataFile.exists()) {
            try {
                playerPlacedBlocks.addAll(Files.readAllLines(dataFile.toPath()));
                getLogger().info("Loaded " + playerPlacedBlocks.size() + " player-placed wood entries.");
            } catch (IOException e) {
                getLogger().warning("Could not load placed_blocks.txt: " + e.getMessage());
            }
        }
    }

    @Override
    public void onDisable() {
        try {
            getDataFolder().mkdirs();
            Files.write(dataFile.toPath(), playerPlacedBlocks);
            getLogger().info("Saved " + playerPlacedBlocks.size() + " player-placed wood entries.");
        } catch (IOException e) {
            getLogger().warning("Could not save placed_blocks.txt: " + e.getMessage());
        }
    }

    private String blockKey(Block block) {
        return block.getWorld().getName() + "," + block.getX() + "," + block.getY() + "," + block.getZ();
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Block b = event.getBlock();
        if (woodenMaterials.contains(b.getType())) {
            playerPlacedBlocks.add(blockKey(b));
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();

        // If the broken block is a wooden-type block and it's marked as player-placed, remove the mark and do nothing.
        if (woodenMaterials.contains(block.getType()) && playerPlacedBlocks.contains(blockKey(block))) {
            playerPlacedBlocks.remove(blockKey(block));
            return;
        }

        // If the broken block is a log (part of a natural tree), perform a simple upward tree cut.
        if (block.getType().name().endsWith("_LOG")) {
            cutTreeUpwards(block);
        }
    }

    // Breaks consecutive LOG blocks upwards until a non-log is encountered.
    private void cutTreeUpwards(Block start) {
        Block current = start;
        while (current != null && current.getType().name().endsWith("_LOG")) {
            current.breakNaturally();
            current = current.getRelative(BlockFace.UP);
        }
    }
}
